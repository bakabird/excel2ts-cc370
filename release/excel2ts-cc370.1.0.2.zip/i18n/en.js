"use strict";
module.exports={
    open_panel:"excel2ts-cc370",
    description:"A tool for converting project Excel to corresponding Ts."
};