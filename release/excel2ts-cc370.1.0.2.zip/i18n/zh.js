"use strict";
module.exports={
    open_panel:"Excel转Ts(cc370)",
    description:"一个将项目Excel转换为对应Ts的工具。"
};